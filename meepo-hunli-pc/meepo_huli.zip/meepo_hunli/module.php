<?php
/**
 * 婚礼邀请函模块定义
 *
 * @author imeepos
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Meepo_hunliModule extends WeModule {



}