<?php
pdo_query("DROP TABLE IF EXISTS ".tablename('meepo_hunli_setting'));
pdo_query("DROP TABLE IF EXISTS ".tablename('meepos_hunli_fuyue'));
pdo_query("DROP TABLE IF EXISTS ".tablename('meepos_hunli_discuss'));

